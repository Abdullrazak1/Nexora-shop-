import 'package:flutter/material.dart';

void main() {
  runApp(MarketApp());
}

class MarketApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سوق إلكتروني',
      home: LoginScreen(),
    );
  }
}

// شاشة تسجيل الدخول البسيطة
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

enum UserType { customer, shopOwner }

class _LoginScreenState extends State<LoginScreen> {
  UserType? selectedUserType;
  final TextEditingController ownerNameController = TextEditingController();

  void _proceed() {
    if (selectedUserType == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('الرجاء اختيار نوع المستخدم')));
      return;
    }
    if (selectedUserType == UserType.shopOwner &&
        ownerNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('الرجاء كتابة اسم المحل')));
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => MarketHomeScreen(
          userType: selectedUserType!,
          ownerName: selectedUserType == UserType.shopOwner
              ? ownerNameController.text.trim()
              : null,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('تسجيل الدخول'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text('اختر نوع المستخدم', style: TextStyle(fontSize: 22)),
            ListTile(
              title: Text('زبون'),
              leading: Radio<UserType>(
                value: UserType.customer,
                groupValue: selectedUserType,
                onChanged: (val) {
                  setState(() {
                    selectedUserType = val;
                  });
                },
              ),
            ),
            ListTile(
              title: Text('صاحب محل'),
              leading: Radio<UserType>(
                value: UserType.shopOwner,
                groupValue: selectedUserType,
                onChanged: (val) {
                  setState(() {
                    selectedUserType = val;
                  });
                },
              ),
            ),
            if (selectedUserType == UserType.shopOwner)
              TextField(
                controller: ownerNameController,
                decoration: InputDecoration(labelText: 'اسم المحل'),
              ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _proceed,
              child: Text('دخول'),
            )
          ],
        ),
      ),
    );
  }
}

class MarketHomeScreen extends StatefulWidget {
  final UserType userType;
  final String? ownerName;

  MarketHomeScreen({required this.userType, this.ownerName});

  @override
  _MarketHomeScreenState createState() => _MarketHomeScreenState();
}

class _MarketHomeScreenState extends State<MarketHomeScreen> {
  final List<String> categories = [
    'طعام',
    'سيارات',
    'أدوات كهربائية',
    'أدوات منزلية',
    'لباس',
  ];

  late Map<String, List<Map<String, dynamic>>> products;

  String selectedCategory = 'طعام';

  List<Map<String, dynamic>> cart = [];

  @override
  void initState() {
    super.initState();
    products = {
      'طعام': [
        {
          'name': 'تفاح',
          'price': 2.5,
          'description': 'تفاح عضوي طازج',
          'image': 'https://i.imgur.com/1h7dx6Y.png',
          'owner': 'محل التفاح الطازج',
        },
        {
          'name': 'خبز',
          'price': 1.0,
          'description': 'خبز طازج من الفرن',
          'image': 'https://i.imgur.com/OFojJoz.png',
          'owner': 'مخبز المدينة',
        },
      ],
      'سيارات': [
        {
          'name': 'زيت محرك',
          'price': 30.0,
          'description': 'زيت محرك عالي الجودة',
          'image': 'https://i.imgur.com/ZXQqx1I.png',
          'owner': 'محل السيارات السريع',
        },
        {
          'name': 'إطار سيارة',
          'price': 50.0,
          'description': 'إطار متين ومريح',
          'image': 'https://i.imgur.com/xaNGIVr.png',
          'owner': 'محل السيارات السريع',
        },
      ],
      'أدوات كهربائية': [
        {
          'name': 'مكواة',
          'price': 25.0,
          'description': 'مكواة كهربائية للملابس',
          'image': 'https://i.imgur.com/RbP9xCZ.png',
          'owner': 'محل الأدوات المنزلية',
        },
      ],
      'أدوات منزلية': [
        {
          'name': 'مقلاة',
          'price': 15.0,
          'description': 'مقلاة غير لاصقة',
          'image': 'https://i.imgur.com/UeOqLnB.png',
          'owner': 'محل الأدوات المنزلية',
        },
      ],
      'لباس': [
        {
          'name': 'قميص',
          'price': 20.0,
          'description': 'قميص قطن مريح',
          'image': 'https://i.imgur.com/SeCtNJK.png',
          'owner': 'محل الملابس الفخمة',
        },
      ],
    };
  }

  List<Map<String, dynamic>> getProductsForCurrentUser() {
    if (widget.userType == UserType.customer) {
      // الزبون يشوف كل المنتجات
      return products[selectedCategory] ?? [];
    } else {
      // صاحب المحل يشوف منتجاته فقط
      return (products[selectedCategory] ?? [])
          .where((p) => p['owner'] == widget.ownerName)
          .toList();
    }
  }

  void addProduct(Map<String, dynamic> product) {
    product['owner'] = widget.ownerName ?? 'زبون';
    products[selectedCategory]?.add(product);
    setState(() {});
  }

  void removeProduct(Map<String, dynamic> product) {
    products[selectedCategory]?.remove(product);
    setState(() {});
  }

  void addToCart(Map<String, dynamic> product) {
    cart.add(product);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product['name']} أضيفت إلى السلة')),
    );
  }

  void _showAddProductDialog() {
    String name = '';
    String description = '';
    String priceStr = '';
    String imageUrl = '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('إضافة منتج جديد'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(labelText: 'اسم المنتج'),
                  onChanged: (val) => name = val,
                ),
                TextField(
                  decoration: InputDecoration(labelText: 'الوصف'),
                  onChanged: (val) => description = val,
                ),
                TextField(
                  decoration: InputDecoration(labelText: 'السعر'),
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  onChanged: (val) => priceStr = val,
                ),
                TextField(
                  decoration: InputDecoration(labelText: 'رابط صورة'),
                  onChanged: (val) => imageUrl = val,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: Text('إلغاء'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              child: Text('إضافة'),
              onPressed: () {
                if (name.isEmpty ||
                    description.isEmpty ||
                    priceStr.isEmpty ||
                    imageUrl.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('يرجى ملء جميع الحقول')),
                  );
                  return;
                }
                double? price = double.tryParse(priceStr);
                if (price == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('السعر غير صالح')),
                  );
                  return;
                }
                addProduct({
                  'name': name,
                  'description': description,
                  'price': price,
                  'image': imageUrl,
                });
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }

  void _goToCartScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartScreen(
          cart: cart,
          onRemove: (product) {
            setState(() {
              cart.remove(product);
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    var userIsOwner = widget.userType == UserType.shopOwner;

    return Scaffold(
      appBar: AppBar(
        title: Text('سوق إلكتروني - $selectedCategory'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: _goToCartScreen,
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              child: Text(
                'الفئات',
                style: TextStyle(fontSize: 24, color: Colors.white),
              ),
              decoration: BoxDecoration(color: Colors.blue),
            ),
            ...categories.map((category) => ListTile(
                  title: Text(category),
                  selected: selectedCategory == category,
                  onTap: () {
                    setState(() {
                      selectedCategory = category;
                      Navigator.pop(context);
                    });
                  },
                )),
            if (userIsOwner)
              ListTile(
                leading: Icon(Icons.add),
                title: Text('إضافة منتج جديد'),
                onTap: () {
                  Navigator.pop(context);
                  _showAddProductDialog();
                },
              ),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: getProductsForCurrentUser().length,
        itemBuilder: (context, index) {
          var product = getProductsForCurrentUser()[index];
          return Card(
            margin: EdgeInsets.all(8),
            child: ListTile(
              leading: Image.network(
                product['image'],
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(product['name']),
              subtitle:
                  Text('${product['description']}\nالسعر: \$${product['price']}'),
              isThreeLine: true,
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ElevatedButton(
                    child: Text('أضف إلى السلة'),
                    onPressed: () => addToCart(product),
                  ),
                  if (userIsOwner)
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        removeProduct(product);
                      },
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class CartScreen extends StatelessWidget {
  final List<Map<String, dynamic>> cart;
  final Function(Map<String, dynamic>) onRemove;

  CartScreen({required this.cart, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    double totalPrice =
        cart.fold(0, (sum, item) => sum + (item['price'] as double));

    return Scaffold(
      appBar: AppBar(
        title: Text('سلة المشتريات'),
      ),
      body: cart.isEmpty
          ? Center(child: Text('السلة فارغة'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (context, index) {
                      var item = cart[index];
                      return ListTile(
                        title: Text(item['name']),
                        subtitle: Text('\$${item['price']}'),
                        trailing: IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => onRemove(item),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    'المجموع: \$${totalPrice.toStringAsFixed(2)}',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
    );
  }
}